from django.contrib import admin
from django.urls import path, include
from solicitudes import views

urlpatterns = [
    #Rutas generales
    path('admin/', admin.site.urls),
    #Rutas solicitudes
    path('solicitudes', views.SolicitudView.as_view(), name='listar-solicitud'),
    path('/editar-solicitud/<int:pk>/', views.SolicitudUpdate.as_view(), name='editar-solicitud'),
    path('/crear-solicitud/', views.SolicitudCreate.as_view(), name='crear-solicitud'),
    path('/eliminar-solicitud/<int:pk>/', views.SolicitudDelete.as_view(), name='eliminar-solicitud'),
    #Rutas Historial de solicitudes
    path('historiales', views.HistorialView.as_view(), name='listar-historial'),
    path('/editar-historial/<int:pk>/', views.HistorialUpdate.as_view(), name='editar-historial'),
    path('/crear-historial/', views.HistorialCreate.as_view(), name='crear-historial'),
    path('/eliminar-historial/<int:pk>/', views.HistorialDelete.as_view(), name='eliminar-historial'),
    #Usuarios
    path('accounts/', include('django.contrib.auth.urls')),
    path('users/', include(('users.urls', 'users'), namespace='users')),
]