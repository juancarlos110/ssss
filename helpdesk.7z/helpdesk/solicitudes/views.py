from django.shortcuts import render
from django.http import HttpResponseRedirect
from .models import (Facultad, Solicitud, CentroTutorial, CentroPrograma, Programa, Servicio, TipoSolicitud, RegistroTipo, SolicitudServicio, Estado, HistorialSolicitud)
#Vistas basadas en clase
from django.views.generic.list import ListView
from django.views.generic.edit import UpdateView, CreateView, DeleteView
from django.urls import reverse

#CRUD para las solicitudes
class SolicitudView(ListView):
    model = Solicitud
    template_name = 'solicitudes/solicitud_list.html'
    context_object_name = 'solicitud'

class SolicitudCreate(CreateView):
    model = Solicitud
    template_name = 'solicitudes/solicitud_form.html'
    fields = ['centrotutorial', 'facultad', 'programa', 'servicio', 'registrotipo', 'tiposolicitud', 'estado', 'descripcion', 'fecha', 'fechaasignacion', 'fechasolucion']

    def get_success_url(self):
        return reverse('listar-solicitud')

class SolicitudUpdate(UpdateView):
    model = Solicitud
    template_name = 'solicitudes/solicitud_form.html'
    fields = ['centrotutorial', 'facultad', 'programa', 'servicio', 'registrotipo', 'tiposolicitud', 'estado', 'descripcion', 'fecha', 'fechaasignacion', 'fechasolucion']

    def get_success_url(self):
        return reverse('listar-solicitud')

class SolicitudDelete(DeleteView):
    model = Solicitud
    template_name = 'solicitudes/solicitud_confirm_delete.html'

    def get_success_url(self):
        return reverse('listar-solicitud')

#CRUD para las Historial de solicitudes
class HistorialView(ListView):
    model = HistorialSolicitud
    template_name = 'historiales/historial_list.html'
    context_object_name = 'historial'

class HistorialCreate(CreateView):
    model = HistorialSolicitud
    template_name = 'historiales/historial_form.html'
    fields = ['solicitud', 'estado', 'descripcion', 'fecha', 'filename', 'docfile']

    def get_success_url(self):
        return reverse('listar-historial')

class HistorialUpdate(UpdateView):
    model = HistorialSolicitud
    template_name = 'historiales/historial_form.html'
    fields = ['solicitud', 'estado', 'descripcion', 'fecha', 'filename', 'docfile']

    def get_success_url(self):
        return reverse('listar-historial')

class HistorialDelete(DeleteView):
    model = HistorialSolicitud
    template_name = 'historiales/historial_confirm_delete.html'

    def get_success_url(self):
        return reverse('listar-historial')