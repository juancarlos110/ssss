from django.db import models
import datetime

class Servicio(models.Model):
    descripcion = models.CharField(max_length=50)
    activo = models.BooleanField()

    def __str__(self):
        return '{}'.format(self.descripcion)

class Estado(models.Model):
    descripcion = models.CharField(max_length=50)
    descripcionPlural = models.CharField(max_length=50,null=True)
    activo = models.BooleanField()

    def __str__(self):
        return '{}'.format(self.descripcion)

class RegistroTipo(models.Model):
    descripcion = models.CharField(max_length=50)
    activo = models.BooleanField()

    def __str__(self):
        return '{}'.format(self.descripcion)

class TipoSolicitud(models.Model):
    descripcion = models.CharField(max_length=50)
    activo = models.BooleanField()

    def __str__(self):
        return '{}'.format(self.descripcion)

class SolicitudServicio(models.Model):
    solicitud = models.ForeignKey(TipoSolicitud, null=False, on_delete=models.PROTECT)
    servicio = models.ForeignKey(Servicio, null=False, on_delete=models.PROTECT)

class CentroTutorial(models.Model):
    descripcion = models.CharField(max_length=50)
    activo = models.BooleanField()

    def __str__(self):
        return '{}'.format(self.descripcion)

class Facultad(models.Model):
    descripcion = models.CharField(max_length=50)
    activo = models.BooleanField()

    def __str__(self):
        return '{}'.format(self.descripcion)

class Programa(models.Model):
    descripcion = models.CharField(max_length=100)
    activo = models.BooleanField()
    facultad = models.ForeignKey(Facultad, null=False, on_delete=models.PROTECT)

    def __str__(self):
        return '{}'.format(self.descripcion)

class CentroPrograma(models.Model):
    centrotutorial = models.ForeignKey(CentroTutorial, null=False, on_delete=models.PROTECT)
    programa = models.ForeignKey(Programa, null=False, on_delete=models.PROTECT)

class Solicitud(models.Model):
    centrotutorial = models.ForeignKey(CentroTutorial, null=False, on_delete=models.PROTECT)
    facultad = models.ForeignKey(Facultad, null=False, on_delete=models.PROTECT)
    programa = models.ForeignKey(Programa, null=False, on_delete=models.PROTECT)
    servicio = models.ForeignKey(Servicio, null=False, on_delete=models.PROTECT)
    registrotipo = models.ForeignKey(RegistroTipo, null=False, on_delete=models.PROTECT)
    tiposolicitud = models.ForeignKey(TipoSolicitud, null=False, on_delete=models.PROTECT)
    estado = models.ForeignKey(Estado, null=False, on_delete=models.PROTECT)
    descripcion = models.CharField(max_length=3200, null=False)
    fecha = models.DateTimeField(default=datetime.datetime.now())
    fechaasignacion = models.DateTimeField(null=True)
    fechasolucion = models.DateTimeField(null=True)

class HistorialSolicitud(models.Model):
    solicitud = models.ForeignKey(Solicitud, null=False, on_delete=models.PROTECT)
    estado = models.ForeignKey(Estado, null=False, on_delete=models.PROTECT)
    descripcion = models.CharField(max_length=1000, null=True)
    fecha = models.DateTimeField(default=datetime.datetime.now())
    filename = models.CharField(max_length=100, null=True)
    #Crear carpeta para guardar los archivos adjuntos
    docfile = models.FileField(null=True, upload_to='respuestas/%Y/%m/%d')