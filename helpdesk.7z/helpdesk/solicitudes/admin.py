from django.contrib import admin
from .models import Servicio, Estado, RegistroTipo, TipoSolicitud, SolicitudServicio, CentroTutorial, Facultad, Programa, CentroPrograma, Solicitud, HistorialSolicitud

#Registrar los modelos para gentionarlos en el administrador
admin.site.register(Servicio)
admin.site.register(Estado)
admin.site.register(RegistroTipo)
admin.site.register(TipoSolicitud)
admin.site.register(SolicitudServicio)
admin.site.register(CentroTutorial)
admin.site.register(Facultad)
admin.site.register(Programa)
admin.site.register(CentroPrograma)
admin.site.register(Solicitud)
admin.site.register(HistorialSolicitud)